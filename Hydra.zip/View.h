#ifndef VIEW_H
#define VIEW_H

#include "Observer.h"

class Controller;
class Board;


class View : public Observer {
	private: 
		Board *board;
		Controller *controller;
		bool test;
   	public:
   		View( Controller*, Board*, bool t );
  		virtual ~View();
  		virtual void update();      // Observer Pattern: concrete update() methd
   		void nextPrompt();	//Regular execution of the game. Prompts for head
		void testPrompt();	//Testing mode. Prompts for new card
}; // View
#endif
