#ifndef SUBJECT_H
#define SUBJECT_H

class Observer;

class Subject {
	private: 	
		Observer *ob;
	public:
	    	void attach( Observer *o );
		void notify();
}; // Subject


#endif
