#ifndef CONTROLLER_H
#define CONTROLLER_H
#include <string> 
class Board;

class Controller {
	private: 
		Board *board;
	public:
		Controller( Board *b );
		void reserve();
		bool play( int head );
		void overwriteCard( std::string v, std::string s );
		void printPlayerStatus();
		void printStatus();
}; // Controller


#endif


