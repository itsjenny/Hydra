#include "Joker.h"
#include <iostream> 
using namespace std;

Joker::Joker() :
	Card{ 0, "J" } 
{}


void Joker::play() {
	bool validVal = false;
	while ( validVal == false ) {
		cout << "Joker value?" << endl;
		string c;
		cin >> c;
		setSym( c );
		if ( c == "2" ) {
			setValue( 2 );
			validVal = true;
		} else if ( c == "3" ) {
			setValue( 3 );
			validVal = true;
		} else if ( c == "4" ) {
			setValue( 4 );
			validVal = true;
		} else if ( c == "5" ) {
			setValue( 5 );
			validVal = true;
		} else if ( c == "6" ) {
			setValue( 6 );
			validVal = true;
		} else if ( c == "7" ) {
			setValue( 7 );
			validVal = true;
		} else if ( c == "8" ) {
			setValue( 8 );
			validVal = true;
		} else if ( c == "9" ) {
			setValue( 9 );
			validVal = true;
		} else if ( c == "10" ) {
			setValue( 10 );
			validVal = true;
		} else if ( c == "A" ) {
			setValue( 1 );
			validVal = true;
		} else if ( c == "J" ) {
			setValue( 11 );
			validVal = true;
		} else if ( c == "Q" ) {
			setValue( 12 );
			validVal = true;
		} else if ( c == "K" ) { 
			setValue( 13 );
			validVal = true;
		} else {
			cout << "Please enter a valid card value of 2-10, J, Q, K, or A" << endl;
		}
	}	
	/*
	if ( this->getValue() == 0 ) {
		cout << "This Joker has yet to be assigned a value " << endl;
	} else {
		cout << "The value of this Joker is " << this->getValue() << endl;
	}*/
}
