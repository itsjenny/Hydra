#ifndef PLAYER_H
#define PLAYER_H
#include <vector>
#include <memory>

class Card;
class Player {
        private:
                int name;
 		std::vector< std::shared_ptr< Card > > discardPile;
		std::vector< std::shared_ptr< Card > > drawPile;	
                std::shared_ptr< Card > reserveCard;
		bool reserve;
		
        public:
		Player();
		~Player();

		//Draw and discard pile actions 
		void addDrawCard( std::shared_ptr< Card >);
		void addDiscardCard( std::shared_ptr< Card >);
		std::shared_ptr< Card > getNext();
		void playCard();
		//Reserve Actions
		void setReserve();
		void swapReserve();
		std::shared_ptr< Card > getReserve() const;
		void removeReserve();

		//Cut Heads
		void cutHead( std::vector< std::shared_ptr < Card > > );

		//Accessors
		int getDrawSize() const;
		int getDiscardSize() const;


};
#endif

