#ifndef CARD_H
#define CARD_H
#include <string>
class Card {
	private:
		int value;
		std::string suit;
		std::string sym;
	public:
		Card( int value, std::string suit);
		~Card();
		void virtual play();

		//Mutatutors
		void setValue( int i );
		void setSym( std::string s );
		void setSuit( std::string s );	

		//Accessors
		int getValue() const;
		std::string getSuit() const;
		std::string getSym() const;

};
#endif



