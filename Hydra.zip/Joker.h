#ifndef JOKER_H
#define JOKER_H

#include "Card.h"

class Joker: public Card {
        public:
		Joker();
                void play() override ;

};
#endif

