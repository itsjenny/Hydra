#include "Board.h"
#include "Controller.h"
#include "View.h"
#include <iostream>
using namespace std;


int main ( int argc, char *args[]) {
	if ( argc == 1 ) {
		//This is running a standard game
		Board board( "none" );
                Controller controller( &board );                // Create controller
                View view( &controller, &board, false );
	} else if ( argc == 2 ) {
		string argument = args[1];
		if ( argument == "-testing" ) {
			cout << "TESTING MODE" << endl;
                        Board board( "testing" );
                        Controller controller ( &board );
                        View view( &controller, &board, true );
		} else if ( argument == "-endgame" ) {
			Board board( "endgame" );
			Controller controller( &board );
                        View view( &controller, &board, false );
		} else if ( argument == "-demo" ) {
			Board board( "demo" );
			Controller controller( &board );
			View view( &controller, &board, false );
		} else { 
			cout << "Invalid command line argument, proceeding with standard game." << endl;
			Board board( "none" );
			Controller controller( &board );
			View view( &controller, &board, false );
		} 
	} else {
	       cout << "Too many command line arguments, sorry!" << endl;
	}	       
	return 0;
}
