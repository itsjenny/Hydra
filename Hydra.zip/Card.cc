#include "Card.h"
#include <string>
using namespace std;

Card::Card( int value, string suit ) :
	value{ value },
	suit{ suit }
{ 
	if ( value == 11 ) {
		sym = "J";
	} else if ( value == 12 ) {
		sym = "Q";
	} else if ( value == 13 ) {
		sym = "K";
	} else if ( value == 1 ) {
		sym = "A";
	} else {
		sym = to_string( value );
	}
}

Card::~Card() {}

void Card::play() {
}

//Mutator
void Card::setValue( int i ) {
	value = i;
}

void Card::setSym( string s ) {
	sym = s;
}

void Card::setSuit( string s ) {
	suit = s;
}
//Accessors

int Card::getValue() const {
	return value;
} 

string Card::getSuit() const {
	return suit;
} 

string Card::getSym() const {
	return sym;
}
