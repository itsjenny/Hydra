#include "Head.h"
#include "Card.h"
#include "Player.h"
#include <vector>
using namespace std;

Head::Head() 
{}

Head::~Head() {}

shared_ptr< Card > Head::getTop() const {
	return contents.back();
}
void Head::addToHead( shared_ptr< Card > c) {
	contents.emplace_back( c );
}

void Head::cutHead( shared_ptr< Player > p ) {
	p->cutHead( contents );
}

int Head::getSize() const {
	return contents.size();
}
