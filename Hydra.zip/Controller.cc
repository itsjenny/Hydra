#include "Controller.h"
#include "Board.h"
#include <iostream> 
using namespace std;


Controller::Controller( Board *b ) :
	board{ b }
{}

void Controller::reserve() {
	return board->reserve();
}

bool Controller::play( int head ) {
	bool ret =  board->playCard( head );
	if ( ret == false ) {
		board->notify();
	}
	return ret;

}

void Controller::overwriteCard( string v, string s ) {
	board->overwrite( v, s );
}

void Controller::printPlayerStatus() {
	board->printPlayerStatus();
}

void Controller::printStatus() {
	board->printStatus();
}
