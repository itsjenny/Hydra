#include "View.h"
#include "Controller.h"
#include "Board.h"
#include <iostream>
using namespace std;
View::View( Controller *c, Board *b, bool t ) : 
	board{ b },
	controller{ c },
	test{ t }
{
	board->attach( this );
	update();
}

View::~View() {}

void View::update() {
	controller->printStatus();
	if ( test ) {
		testPrompt();
	} else {
		nextPrompt();
	}
}


void View::nextPrompt() {
	//controller->printStatus();
	controller->printPlayerStatus();
	int command;
	bool end;
	cin >> command;
	if ( !cin.eof() ) {
		if ( command == 0 ) {
			controller->reserve();
		} else {
			end = controller->play( command );
			if ( end == true ) {
				cout << "Player " << board->getCurrent() << " wins!" << endl;
			}
		}
	} 
}

void View::testPrompt() {
	//Valid values
	string validV [] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "Joker" };
	string validS [] = { "S", "H", "D", "C" };
	string v;
	string s;
	bool validVal = false;
        bool validSuit = false;
	cout << "Card value?" << endl;
	cin >> v;
	if ( !cin.eof() ) {
		for ( int i = 0; i < 14; i++ ) {
			if ( validV[i] == v ) {
				//then the card value is valid.
				validVal = true;
			}
		}
		if ( v != "Joker" ) {
			cout << "Suit?" << endl;
			cin >> 	s;
			for ( int j = 0; j < 4; j++ ) {
				if ( validS[j] == s ){
					validSuit = true;
				}
			}
		} else if ( v == "Joker" ) {
			s = "J";
			validSuit = true;
		}

		//If both prompts were valid, then make the card
		if ( validVal && validSuit ) {
			controller->overwriteCard( v, s );
			nextPrompt();
		} else {
			//Otherwise prompt again
			cout << "Sorry, that wasn't valid information for a card, try again. " << endl;
			testPrompt();
		}
	}	
}
