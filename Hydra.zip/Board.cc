#include "Board.h"
#include "Card.h"
#include "Joker.h"
#include "Player.h"
#include "Head.h"

#include <vector> 
#include <map>
#include <memory>
#include <iostream>
#include <string>
#include <algorithm> 
#include <random>
#include <chrono>
#include <iomanip>

using namespace std;

Board::Board ( string s ):
	current{ 1 },
	toPlace{ 0 },
	state{ s }
{
        //Game Start
        while ( true ) {
		cout << "How many players?" << endl;
		cin >> numPlayers;
		if ( numPlayers > 0 ) {
			break;
		} else {
			cout << "Please enter a positive number of players" << endl;
		}
	}

	cout << endl;
	setupCards();
	dealCards();
	printInitialStatus();

}

Board::~Board() {}


//Makes the card pointers, players, and deals the appropriate number of cards to players
void Board::setupCards() {
	//Making a deck of cards
	string suits [] = { "D", "H", "S", "C" };
	for ( int i = 0; i < numPlayers; i++ ) {
		//Making the standard cards
		for ( int s = 0; s < 4; s++ ) {
			for ( int v = 13; v >= 1; v-- ) {
				deck.emplace_back( make_shared< Card >( v, suits[s] ) );
			}
		}
		//Making the Jokers
		deck.emplace_back( make_shared< Joker >() );
		deck.emplace_back( make_shared< Joker >() );
	}
	
	//Making Players
	for (int p = 1; p <= numPlayers; p++) {
		players[p] = make_shared< Player >();
	}
}

//Depending on what state indicated by command line args, set the game state
void Board::dealCards() {
	if ( state == "demo" || state == "endgame" ) {
		// seeded shuffle
		auto eng = std::default_random_engine {};
		std::shuffle(deck.begin(), deck.end(), eng);
	} else {
		//Regular shuffle
	        unsigned seed = chrono::system_clock::now().time_since_epoch().count();
        	shuffle( deck.begin(), deck.end(), default_random_engine( seed ) );
	}
	
	//Stardard game. 54 cards each player, 1 starting head
	while ( !deck.empty() ) {
		for ( int n = 1; n <= numPlayers; n++ ) {
			players.at( n )->addDrawCard( deck.back() );
			deck.pop_back();
		}
	}
	
	
	if ( state == "none" || state == "demo" ) {
		//Place down the first head
        	heads[ current ] = make_shared< Head >();
        	if ( players.at( current )->getNext()->getSuit() == "J" ) {
        	        players.at( current )->getNext()->setValue( 2 );
        	        players.at( current )->getNext()->setSym( "2" );
        	}
        	heads.at( current )->addToHead( players.at( 1 )->getNext() );
        	players.at( current )->playCard();
	} else if ( state == "endgame" ) {
		//Set reduced cards, in this state, say there are as many active heads as there are players, and each player is left with two cards each
		for ( int i = 1; i <= numPlayers; i++ ) {
			heads[i] = make_shared< Head >();
			for ( int j = 0; j < 52; j++ ) {
				heads.at( i )->addToHead( players.at( i )->getNext() );
				players.at( i )->playCard();
			}
		}
	} else if ( state == "testing" ){
		cout << "Please enter the information for the new head" << endl;
		overwriteHead();
		 heads[ current ] = make_shared< Head >();
                if ( players.at( current )->getNext()->getSuit() == "J" ) {
                        players.at( current )->getNext()->setValue( 2 );
                        players.at( current )->getNext()->setSym( "2" );
                }
                heads.at( current )->addToHead( players.at( 1 )->getNext() );
                players.at( current )->playCard();
        }

}


void Board::overwriteHead() {
	 //Valid values
        string validV [] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "Joker" };
        string validS [] = { "S", "H", "D", "C" };
        string v;
        string s;
        bool validVal = false;
        bool validSuit = false;
        cout << "Card value?" << endl;
        cin >> v;
        if ( !cin.eof() ) {
                for ( int i = 0; i < 14; i++ ) {
                        if ( validV[i] == v ) {
                                //then the card value is valid.
                                validVal = true;
                        }
                }
                if ( v != "Joker" ) {
                        cout << "Suit?" << endl;
                        cin >>  s;
                        for ( int j = 0; j < 4; j++ ) {
                                if ( validS[j] == s ){
                                        validSuit = true;
                                }
                        }
                } else if ( v == "Joker" ) {
                        s = "J";
                        validSuit = true;
                }

                //If both prompts were valid, then make the card
                if ( validVal && validSuit ) {
                        overwrite( v, s );
                } else {
                        //Otherwise prompt again
                        cout << "Sorry, that wasn't valid information for a card, try again. " << endl;
                        overwriteHead();
                }
        }
}


//Make new Heads
void Board::makeHeads() {
	int index = heads.begin()->first + heads.size();
	//remove the first head
	heads.erase( heads.begin()->first );

	//If in testing mode, prompt for values
	for ( int i = 0; i < 2; i++ ) {
		if ( state == "testing" ) {
			cout << "Please enter the information for the new head" << endl;
			overwriteHead();
		}
		//If either card placed down is a Joker, assign it a value of 2
		if ( players.at( current )->getNext()->getValue() == 0 ) {
			players.at( current )->getNext()->setValue( 2 );
			players.at( current )->getNext()->setSym( "2" );
		}
		heads[ index + i ] = make_shared< Head >();
		heads.at( index + i )->addToHead( players.at( current )->getNext() );
		players.at( current )->playCard();
	}
}


//Swapping reserve card
void Board::reserve() {
	if ( heads.size() > 1 ) {
		if ( players.at( current )->getReserve() == nullptr ) {
			players.at( current )->setReserve();
		} else {
			players.at( current )->swapReserve();
		}
	} else { 
		cout << "\n\tYou can't set a reserve card if there is only one head!" << endl;
	}
	notify();
}


//Playing a card!
bool Board::playCard( int h ) {
	//Check if the input is a valid head
	int size = heads.size();
	if ( h >= heads.begin()->first && h <= heads.begin()->first + size - 1  ) {
		//If the players card is a joker assign the value
		players.at( current )->getNext()->play();
		int v = players.at( current )->getNext()->getValue();
		string suit = players.at( current )->getNext()->getSuit();

		//If value of card is same as head, play card and end turn
		if ( v == heads.at( h )->getTop()->getValue() ) {
			heads.at( h )->addToHead(players.at( current )->getNext() );
	                players.at( current )->playCard();
			toPlace = heads.size();

		} else if ( v < heads.at( h )->getTop()->getValue() || heads.at( h )->getTop()->getValue() == 1 ) {
			//If value of card is less than head, we can place it
			heads.at( h )->addToHead(players.at( current )->getNext() );
                        players.at( current )->playCard();
			toPlace++;

		} else if ( h == heads.begin()->first ) {
			//Check that there are no other playable moves
			for ( auto i = heads.begin(); i != heads.end(); ++i ) {
				if ( v <= i->second->getTop()->getValue() ) {
					cout << "\n\tThere are still playable moves without cutting off a head" << endl;
					return false;
				}
			}
			//If the card is a joker, you can't purposely cut heads.
			if ( suit == "J" ) {
				cout << "\n\tYou cannot cut heads with a Joker" << endl;
				return false;
			} else {
				//There are no other playable moves. Place current card in discard, place reserve in discard. Cut heads, make two new heads
				heads.at( heads.begin()->first )->cutHead( players.at( current ) );
				makeHeads();
				toPlace = heads.size();
			}
	
		} else {
			//No valid move with that head
			cout << "\n\tRemember your card has to be less than the value of the head!" << endl;
			return false;
		}

		//Here if a card was put down
		//if the player has no more cards they win
		if ( players.at( current )->getDrawSize() + players.at( current )->getDiscardSize() == 0 ) {
			players.at( current )->removeReserve();
			if ( players.at( current )->getDiscardSize() == 0 ) {
				return true;
			} else {
				//They still have a reserve card, so their turn ends;
				toPlace = heads.size();
			}
                }

		//A card has been played, now check for remaining cards in hand
		size = heads.size();
		if ( toPlace == size ) {
			//If the player has exhausted the cards they can place
			players.at( current )->removeReserve();	
			//If the player runs out of cards they win
	                if ( players.at( current )->getDrawSize() + players.at( current )->getDiscardSize() == 0 ) {
	                        return true;
			}
			current++;
			if ( current > numPlayers ) {
				current = 1;
			}
			toPlace = 0;
		}
	} else {
		cout <<  "\n\tHead selected was out of range. Please select a head between " << heads.begin()->first << " and " << heads.begin()->first + heads.size() - 1 << "!" << endl;
	}
	//otherwise ignore the move so the player and the #of cards to place stays the same. Update the view
	return false;
}

//Returns whose turn it is
int Board::getCurrent() const {
	return current;
}


//TESTING MODE overwriting the players card.
void Board::overwrite( string v, string s ) {
	int value;
	if ( v == "Joker" ) {
                //convert the card into a Joker
                players.at( current )->playCard();
                players.at( current )->addDrawCard( make_shared< Joker >() );
        } else {
		if ( v == "J" ) value = 11;
		else if ( v == "Q" ) value = 12;
		else if ( v == "K" ) value = 13;
		else if ( v == "A" ) value = 1;
		else value = stoi( v );
	
		players.at( current )->getNext()->setValue( value );
		players.at( current )->getNext()->setSym( v );
		players.at( current )->getNext()->setSuit( s );
	}
}
	

//in game status
void Board::printStatus() {
	int size = heads.size();
	//Output heads and their top values
	cout << "\nHeads:"<< endl;
	for ( auto it = heads.begin(); it != heads.end(); ++it ) {
		cout << it->first << ": " << it->second->getTop()->getSym() << it->second->getTop()->getSuit() << " ("<< it->second->getSize() << ")"<<endl;
	}
	//Output Players and their information
	cout << "\n" << "Players:" << endl;
	for ( auto const &p: players ){
		cout << "Player " << p.first << ": " << (p.second->getDiscardSize() + p.second->getDrawSize() ) << " (" << p.second->getDrawSize();
	        cout << " draw, " << p.second->getDiscardSize() << " discard)";
		if ( p.first == current ) {
			int r;
			if (p.second->getReserve() == nullptr ) {
				r = 0;
			} else {
				r = 1;
			}
		cout << " + 1 in hand, " << size - 1 - toPlace <<" remaining, " << r << " in reserve" << endl;
		} else {
			cout << endl;
		}
	}
	cout << endl;

}

void Board::printPlayerStatus() {
        string card;
        if ( players.at( current )->getNext()->getSuit() == "J" ) {
                card = "Joker";
        } else {
                card = players.at( current )->getNext()->getSym() + players.at( current )->getNext()->getSuit();
        }

	cout << "Player " << current << ", you are holding a " << card << ". Your move?" << endl;
}

void Board::printInitialStatus() {
        //Print out initial status
        cout << "\nHeads:"<< endl;
        for ( auto it = heads.begin(); it != heads.end(); ++it ) {
                cout << it->first << ": " << it->second->getTop()->getSym() << it->second->getTop()->getSuit() << " ("<< it->second->getSize() << ")"<<endl;
        }
        cout << "\n" << "Players:" << endl;
        for ( auto const &p: players ){
                cout << "Player " << p.first << ": " << (p.second->getDiscardSize() + p.second->getDrawSize() ) << " (" << p.second->getDrawSize() << " draw, " << p.second->getDiscardSize() << " discard)"<< endl;
        }
        current++;
        if ( current > numPlayers ) {
                current = 1;
        }
        cout << "\nPlayer "<< current << " it is your turn" << endl;
        string c;
	getline( cin, c );
}
