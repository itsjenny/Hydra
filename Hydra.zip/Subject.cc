#include "Subject.h"
#include "Observer.h"

void Subject::attach(Observer *o) { 
	ob = o;
}

void Subject::notify() {
	ob->update();
}

