#include "Player.h"
#include "Card.h"
#include <memory>
#include <random>
#include <algorithm>
#include <chrono>
#include <iostream>
using namespace std;

//Constructor
Player::Player() 
{
	reserve = false;
}

//Destructor
Player::~Player() {}

void Player::addDrawCard( shared_ptr< Card > r ) {
	drawPile.emplace_back( r );
}

void Player::addDiscardCard( shared_ptr< Card > r ) {
	discardPile.emplace_back( r );
}


//Reserve Actions
void Player::setReserve() {
	if ( drawPile.size() > 1 || discardPile.size() != 0 ) {
		reserveCard = getNext();
		if ( reserveCard != nullptr ) {
			drawPile.pop_back();
		}
	}
}

void Player::swapReserve() {
	auto r = getNext();
	if ( r != nullptr ) {
		drawPile.pop_back();
		drawPile.emplace_back( reserveCard );
		reserveCard = r;
	}
}

shared_ptr< Card > Player::getReserve() const {
        return reserveCard;
}

void Player::removeReserve() {
	if ( reserveCard != nullptr ) {
		addDiscardCard( reserveCard );
		reserveCard = nullptr;
	}
}


//Play actions
shared_ptr< Card >Player::getNext() {
	//If the draw pile is empty, shuffle the discard pile into it
        if ( drawPile.size() == 0 && discardPile.size() != 0 ) {
		unsigned seed = chrono::system_clock::now().time_since_epoch().count();
        	shuffle( discardPile.begin(), discardPile.end(), default_random_engine( seed ) );
		for ( auto cards: discardPile ) {
			drawPile.emplace_back( discardPile.back() );
			discardPile.pop_back();
		}
		return drawPile.back();
	} else if ( drawPile.size() == 0 && discardPile.size() == 0 ) {
		return nullptr;
	} else {
		return drawPile.back();
	}
}

void Player::cutHead( vector < shared_ptr< Card > > pile ) {
	addDiscardCard( getNext() );
	playCard();
	removeReserve();
	for ( auto n : pile ) {
		discardPile.emplace_back( pile.back() );
		pile.pop_back();
	}
}

void Player::playCard() {
	drawPile.pop_back();
}


//Accessors
int Player::getDrawSize() const {
	return drawPile.size();
}

int Player::getDiscardSize() const {
	return discardPile.size();
}

