#ifndef HEAD_H
#define HEAD_H
#include <memory>
#include <vector>

class Card;
class Player;
class Head {
	private:
		std::vector< std::shared_ptr < Card > > contents;
	public:
		Head();
		~Head();
		void addToHead( std::shared_ptr< Card > );
		void cutHead( std::shared_ptr< Player > );
		
		//Accessors
		std::shared_ptr< Card > getTop() const ;
		int getSize() const;	
};
#endif
