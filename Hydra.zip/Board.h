#ifndef BOARD_H
#define BOARD_H

#include <vector>
#include <map>
#include <memory>

#include "Card.h"
#include "Joker.h"
#include "Player.h"
#include "Head.h"
#include "Subject.h"

class Player;
class Card;
class Board : public Subject {
	private: 
		std::map< int, std::shared_ptr< Player > > players;
		std::vector< std::shared_ptr< Card > > deck;
		std::map< int, std::shared_ptr< Head > > heads;
		int current;
		int toPlace;
		int numPlayers;
		std::string state;
	public:
	       	Board( std::string );	
		~Board();
		//Initial Setup
		void setupCards();
		void dealCards();
		//Printing game status
		void printStatus();
		void printInitialStatus();
		void printPlayerStatus();	
		
		//Actions
		void makeHeads();
		void reserve();
		bool playCard( int head );

		//Accessors
		int getCurrent() const;

		//Testing mode
		void overwrite( std::string v, std::string s );
		void overwriteHead();
		
};

#endif

